# EspressoExamples
A collection of examples demonstrating different techniques for automated testing with Espresso.

![alt tag](screens/main_activity.png)
